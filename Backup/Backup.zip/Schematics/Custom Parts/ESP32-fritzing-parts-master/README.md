# fritzing-parts
A library of parts for Fritzing

#### ESP32
ESP32-Doit_lunanode iamge and ESP-WROOM-32 breakout board COMPACT(a bit better circuit) image
![ESP32-fritzing-parts](/src/esp32_2images.png)

#### TTL-CP2102
![CP-2102](/src/ttl_cp2102.png)

## License
Released under CC Attribution Share-Alike 4.0.
